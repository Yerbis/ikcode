def search4vowels(phrase:str):
    '''Return a string based on any vowels found''' # Docstring, describes the function 
    vowels = set('aeiou')
    return vowels.intersection(set(phrase))


inpt = input("Provide a word to search for vowels (No caps):  ")

vwls = search4vowels(inpt)

print(vwls)


def search4letters(phrase:str, letters:str):
    '''Return a set of the 'letters' found in 'phrase'.'''
    return set(letters).intersection(set(phrase))
